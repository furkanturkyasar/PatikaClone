package com.patikadev.Model;

public class Operator extends User {
    public Operator() {

    }

    public Operator(int id, String name, String uname, String pass, String type) {
        super(id, name, uname, pass, type);
    }
}
