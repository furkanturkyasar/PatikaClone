package com.patikadev.Helper;

public class Config {
    public static final String PROJECT_TITLE = "Patika.Dev";
    public static final String DB_URL = "jdbc:mysql://localhost/patika";
    public static final String DB_USERNAME = "root";
    public static final String DB_PASSWORD = "mysql";
}
